Use health_records;
INSERT INTO Patient (FirstName, LastName, DateOfBirth, Gender, PhoneNumber, Email, Address, EmergencyContact)
VALUES ('Димитър', 'Иванов', '1990-05-15', 'Мъж', '0888123456', 'dimitar.ivanov@example.com', 'ул. Витоша 10, София', '0888543210');
Use health_records;
INSERT INTO Prescription (RecordId, MedicineName, Dosage, Instructions, PrescriptionDate)
VALUES (1, 'Амброксол', '15ml', '3 пъти дневно след хранене', '2025-01-12');
Use health_records;
INSERT INTO MedicalRecord (PatientId, DoctorId, Diagnosis, Treatment, VisitDate, NextVisitDate)
VALUES (1, 2, 'Бронхит', 'Ингалатор, сироп за кашлица', '2025-01-12', '2025-01-19');
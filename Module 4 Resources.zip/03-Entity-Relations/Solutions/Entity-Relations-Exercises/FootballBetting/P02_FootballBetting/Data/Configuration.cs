﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_FootballBetting.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server =.;Database = FootballBetting;Integrated Security = True";
    }
}

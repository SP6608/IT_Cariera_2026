﻿namespace One_to_Many.Data
{
    public class Config
    {
        public static string stringConfiguration =
            @"Server=(localdb)\mssqllocaldb;Database=OneToOne";
    }
}

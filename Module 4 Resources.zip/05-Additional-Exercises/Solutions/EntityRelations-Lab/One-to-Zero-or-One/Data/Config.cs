﻿namespace One_to_One.Data
{
    public class Config
    {
        public static string stringConfiguration =
            @"Server=(localdb)\mssqllocaldb;Database=OneToOne";
    }
}

﻿namespace MusicProvider.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\mssqllocaldb;Database=MusicProvider;Trusted_Connection=True";
    }
}